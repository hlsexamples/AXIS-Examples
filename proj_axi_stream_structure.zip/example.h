#ifndef EXAMPLE_H
#define EXAMPLE_H

#define TEST_SIZE 4
#include "ap_int.h"

struct DataTypeIn {
	ap_int<1>	valid;
    ap_int<32>  data_a;
    ap_int<32>  data_b;
};

struct DataTypeOut {
	ap_int<1>	valid;
    ap_int<32>  data;
};


void example(struct DataTypeIn A, struct DataTypeOut *X);

#endif
